Nunito Sans Variable Font
=========================

This download contains Nunito Sans as both variable fonts and static fonts.

Nunito Sans is a variable font with these axes:
  YTLC
  opsz
  wdth
  wght

This means all the styles are contained in these files:
  NunitoSans-VariableFont_YTLC,opsz,wdth,wght.ttf
  NunitoSans-Italic-VariableFont_YTLC,opsz,wdth,wght.ttf

If your app fully supports variable fonts, you can now pick intermediate styles
that aren’t available as static fonts. Not all apps support variable fonts, and
in those cases you can use the static font files for Nunito Sans:
  static/NunitoSans_7pt_Condensed-ExtraLight.ttf
  static/NunitoSans_7pt_Condensed-Light.ttf
  static/NunitoSans_7pt_Condensed-Regular.ttf
  static/NunitoSans_7pt_Condensed-Medium.ttf
  static/NunitoSans_7pt_Condensed-SemiBold.ttf
  static/NunitoSans_7pt_Condensed-Bold.ttf
  static/NunitoSans_7pt_Condensed-ExtraBold.ttf
  static/NunitoSans_7pt_Condensed-Black.ttf
  static/NunitoSans_7pt_SemiCondensed-ExtraLight.ttf
  static/NunitoSans_7pt_SemiCondensed-Light.ttf
  static/NunitoSans_7pt_SemiCondensed-Regular.ttf
  static/NunitoSans_7pt_SemiCondensed-Medium.ttf
  static/NunitoSans_7pt_SemiCondensed-SemiBold.ttf
  static/NunitoSans_7pt_SemiCondensed-Bold.ttf
  static/NunitoSans_7pt_SemiCondensed-ExtraBold.ttf
  static/NunitoSans_7pt_SemiCondensed-Black.ttf
  static/NunitoSans_7pt-ExtraLight.ttf
  static/NunitoSans_7pt-Light.ttf
  static/NunitoSans_7pt-Regular.ttf
  static/NunitoSans_7pt-Medium.ttf
  static/NunitoSans_7pt-SemiBold.ttf
  static/NunitoSans_7pt-Bold.ttf
  static/NunitoSans_7pt-ExtraBold.ttf
  static/NunitoSans_7pt-Black.ttf
  static/NunitoSans_7pt_SemiExpanded-ExtraLight.ttf
  static/NunitoSans_7pt_SemiExpanded-Light.ttf
  static/NunitoSans_7pt_SemiExpanded-Regular.ttf
  static/NunitoSans_7pt_SemiExpanded-Medium.ttf
  static/NunitoSans_7pt_SemiExpanded-SemiBold.ttf
  static/NunitoSans_7pt_SemiExpanded-Bold.ttf
  static/NunitoSans_7pt_SemiExpanded-ExtraBold.ttf
  static/NunitoSans_7pt_SemiExpanded-Black.ttf
  static/NunitoSans_7pt_Expanded-ExtraLight.ttf
  static/NunitoSans_7pt_Expanded-Light.ttf
  static/NunitoSans_7pt_Expanded-Regular.ttf
  static/NunitoSans_7pt_Expanded-Medium.ttf
  static/NunitoSans_7pt_Expanded-SemiBold.ttf
  static/NunitoSans_7pt_Expanded-Bold.ttf
  static/NunitoSans_7pt_Expanded-ExtraBold.ttf
  static/NunitoSans_7pt_Expanded-Black.ttf
  static/NunitoSans_10pt_Condensed-ExtraLight.ttf
  static/NunitoSans_10pt_Condensed-Light.ttf
  static/NunitoSans_10pt_Condensed-Regular.ttf
  static/NunitoSans_10pt_Condensed-Medium.ttf
  static/NunitoSans_10pt_Condensed-SemiBold.ttf
  static/NunitoSans_10pt_Condensed-Bold.ttf
  static/NunitoSans_10pt_Condensed-ExtraBold.ttf
  static/NunitoSans_10pt_Condensed-Black.ttf
  static/NunitoSans_10pt_SemiCondensed-ExtraLight.ttf
  static/NunitoSans_10pt_SemiCondensed-Light.ttf
  static/NunitoSans_10pt_SemiCondensed-Regular.ttf
  static/NunitoSans_10pt_SemiCondensed-Medium.ttf
  static/NunitoSans_10pt_SemiCondensed-SemiBold.ttf
  static/NunitoSans_10pt_SemiCondensed-Bold.ttf
  static/NunitoSans_10pt_SemiCondensed-ExtraBold.ttf
  static/NunitoSans_10pt_SemiCondensed-Black.ttf
  static/NunitoSans_10pt-ExtraLight.ttf
  static/NunitoSans_10pt-Light.ttf
  static/NunitoSans_10pt-Regular.ttf
  static/NunitoSans_10pt-Medium.ttf
  static/NunitoSans_10pt-SemiBold.ttf
  static/NunitoSans_10pt-Bold.ttf
  static/NunitoSans_10pt-ExtraBold.ttf
  static/NunitoSans_10pt-Black.ttf
  static/NunitoSans_10pt_SemiExpanded-ExtraLight.ttf
  static/NunitoSans_10pt_SemiExpanded-Light.ttf
  static/NunitoSans_10pt_SemiExpanded-Regular.ttf
  static/NunitoSans_10pt_SemiExpanded-Medium.ttf
  static/NunitoSans_10pt_SemiExpanded-SemiBold.ttf
  static/NunitoSans_10pt_SemiExpanded-Bold.ttf
  static/NunitoSans_10pt_SemiExpanded-ExtraBold.ttf
  static/NunitoSans_10pt_SemiExpanded-Black.ttf
  static/NunitoSans_10pt_Expanded-ExtraLight.ttf
  static/NunitoSans_10pt_Expanded-Light.ttf
  static/NunitoSans_10pt_Expanded-Regular.ttf
  static/NunitoSans_10pt_Expanded-Medium.ttf
  static/NunitoSans_10pt_Expanded-SemiBold.ttf
  static/NunitoSans_10pt_Expanded-Bold.ttf
  static/NunitoSans_10pt_Expanded-ExtraBold.ttf
  static/NunitoSans_10pt_Expanded-Black.ttf
  static/NunitoSans_7pt_Condensed-ExtraLightItalic.ttf
  static/NunitoSans_7pt_Condensed-LightItalic.ttf
  static/NunitoSans_7pt_Condensed-Italic.ttf
  static/NunitoSans_7pt_Condensed-MediumItalic.ttf
  static/NunitoSans_7pt_Condensed-SemiBoldItalic.ttf
  static/NunitoSans_7pt_Condensed-BoldItalic.ttf
  static/NunitoSans_7pt_Condensed-ExtraBoldItalic.ttf
  static/NunitoSans_7pt_Condensed-BlackItalic.ttf
  static/NunitoSans_7pt_SemiCondensed-ExtraLightItalic.ttf
  static/NunitoSans_7pt_SemiCondensed-LightItalic.ttf
  static/NunitoSans_7pt_SemiCondensed-Italic.ttf
  static/NunitoSans_7pt_SemiCondensed-MediumItalic.ttf
  static/NunitoSans_7pt_SemiCondensed-SemiBoldItalic.ttf
  static/NunitoSans_7pt_SemiCondensed-BoldItalic.ttf
  static/NunitoSans_7pt_SemiCondensed-ExtraBoldItalic.ttf
  static/NunitoSans_7pt_SemiCondensed-BlackItalic.ttf
  static/NunitoSans_7pt-ExtraLightItalic.ttf
  static/NunitoSans_7pt-LightItalic.ttf
  static/NunitoSans_7pt-Italic.ttf
  static/NunitoSans_7pt-MediumItalic.ttf
  static/NunitoSans_7pt-SemiBoldItalic.ttf
  static/NunitoSans_7pt-BoldItalic.ttf
  static/NunitoSans_7pt-ExtraBoldItalic.ttf
  static/NunitoSans_7pt-BlackItalic.ttf
  static/NunitoSans_7pt_SemiExpanded-ExtraLightItalic.ttf
  static/NunitoSans_7pt_SemiExpanded-LightItalic.ttf
  static/NunitoSans_7pt_SemiExpanded-Italic.ttf
  static/NunitoSans_7pt_SemiExpanded-MediumItalic.ttf
  static/NunitoSans_7pt_SemiExpanded-SemiBoldItalic.ttf
  static/NunitoSans_7pt_SemiExpanded-BoldItalic.ttf
  static/NunitoSans_7pt_SemiExpanded-ExtraBoldItalic.ttf
  static/NunitoSans_7pt_SemiExpanded-BlackItalic.ttf
  static/NunitoSans_7pt_Expanded-ExtraLightItalic.ttf
  static/NunitoSans_7pt_Expanded-LightItalic.ttf
  static/NunitoSans_7pt_Expanded-Italic.ttf
  static/NunitoSans_7pt_Expanded-MediumItalic.ttf
  static/NunitoSans_7pt_Expanded-SemiBoldItalic.ttf
  static/NunitoSans_7pt_Expanded-BoldItalic.ttf
  static/NunitoSans_7pt_Expanded-ExtraBoldItalic.ttf
  static/NunitoSans_7pt_Expanded-BlackItalic.ttf
  static/NunitoSans_10pt_Condensed-ExtraLightItalic.ttf
  static/NunitoSans_10pt_Condensed-LightItalic.ttf
  static/NunitoSans_10pt_Condensed-Italic.ttf
  static/NunitoSans_10pt_Condensed-MediumItalic.ttf
  static/NunitoSans_10pt_Condensed-SemiBoldItalic.ttf
  static/NunitoSans_10pt_Condensed-BoldItalic.ttf
  static/NunitoSans_10pt_Condensed-ExtraBoldItalic.ttf
  static/NunitoSans_10pt_Condensed-BlackItalic.ttf
  static/NunitoSans_10pt_SemiCondensed-ExtraLightItalic.ttf
  static/NunitoSans_10pt_SemiCondensed-LightItalic.ttf
  static/NunitoSans_10pt_SemiCondensed-Italic.ttf
  static/NunitoSans_10pt_SemiCondensed-MediumItalic.ttf
  static/NunitoSans_10pt_SemiCondensed-SemiBoldItalic.ttf
  static/NunitoSans_10pt_SemiCondensed-BoldItalic.ttf
  static/NunitoSans_10pt_SemiCondensed-ExtraBoldItalic.ttf
  static/NunitoSans_10pt_SemiCondensed-BlackItalic.ttf
  static/NunitoSans_10pt-ExtraLightItalic.ttf
  static/NunitoSans_10pt-LightItalic.ttf
  static/NunitoSans_10pt-Italic.ttf
  static/NunitoSans_10pt-MediumItalic.ttf
  static/NunitoSans_10pt-SemiBoldItalic.ttf
  static/NunitoSans_10pt-BoldItalic.ttf
  static/NunitoSans_10pt-ExtraBoldItalic.ttf
  static/NunitoSans_10pt-BlackItalic.ttf
  static/NunitoSans_10pt_SemiExpanded-ExtraLightItalic.ttf
  static/NunitoSans_10pt_SemiExpanded-LightItalic.ttf
  static/NunitoSans_10pt_SemiExpanded-Italic.ttf
  static/NunitoSans_10pt_SemiExpanded-MediumItalic.ttf
  static/NunitoSans_10pt_SemiExpanded-SemiBoldItalic.ttf
  static/NunitoSans_10pt_SemiExpanded-BoldItalic.ttf
  static/NunitoSans_10pt_SemiExpanded-ExtraBoldItalic.ttf
  static/NunitoSans_10pt_SemiExpanded-BlackItalic.ttf
  static/NunitoSans_10pt_Expanded-ExtraLightItalic.ttf
  static/NunitoSans_10pt_Expanded-LightItalic.ttf
  static/NunitoSans_10pt_Expanded-Italic.ttf
  static/NunitoSans_10pt_Expanded-MediumItalic.ttf
  static/NunitoSans_10pt_Expanded-SemiBoldItalic.ttf
  static/NunitoSans_10pt_Expanded-BoldItalic.ttf
  static/NunitoSans_10pt_Expanded-ExtraBoldItalic.ttf
  static/NunitoSans_10pt_Expanded-BlackItalic.ttf

Get started
-----------

1. Install the font files you want to use

2. Use your app's font picker to view the font family and all the
available styles

Learn more about variable fonts
-------------------------------

  https://developers.google.com/web/fundamentals/design-and-ux/typography/variable-fonts
  https://variablefonts.typenetwork.com
  https://medium.com/variable-fonts

In desktop apps

  https://theblog.adobe.com/can-variable-fonts-illustrator-cc
  https://helpx.adobe.com/nz/photoshop/using/fonts.html#variable_fonts

Online

  https://developers.google.com/fonts/docs/getting_started
  https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Fonts/Variable_Fonts_Guide
  https://developer.microsoft.com/en-us/microsoft-edge/testdrive/demos/variable-fonts

Installing fonts

  MacOS: https://support.apple.com/en-us/HT201749
  Linux: https://www.google.com/search?q=how+to+install+a+font+on+gnu%2Blinux
  Windows: https://support.microsoft.com/en-us/help/314960/how-to-install-or-remove-a-font-in-windows

Android Apps

  https://developers.google.com/fonts/docs/android
  https://developer.android.com/guide/topics/ui/look-and-feel/downloadable-fonts

License
-------
Please read the full license text (OFL.txt) to understand the permissions,
restrictions and requirements for usage, redistribution, and modification.

You can use them in your products & projects – print or digital,
commercial or otherwise.

This isn't legal advice, please consider consulting a lawyer and see the full
license for all details.
